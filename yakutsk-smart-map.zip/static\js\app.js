'use strict';

/* =========================================================================
 * Умная карта Якутска — фронтенд.
 *
 * Карта:      Leaflet.js + тайлы OpenStreetMap (без бэкенда).
 * Данные:     static/js/data.js (window.OBJECTS).
 * ИИ:         POST /api/ask → Flask-прокси → YandexGPT (или демо-режим).
 *
 * Ключевые функции:
 *   buildContext()     — формирование контекста для ИИ (объекты + координаты
 *                        + расстояния dist_m от выбранного объекта/центра);
 *   highlightMentioned() — подсветка объектов, упомянутых в ответе ИИ;
 *   askQuestion()      — отправка вопроса, обработка ошибок и таймаута.
 * ========================================================================= */

const TYPE_LABELS = {
  school: 'Школа',
  clinic: 'Поликлиника',
  transport: 'Транспорт',
  park: 'Парк',
};
const TYPE_EMOJI = {
  school: '🎓',
  clinic: '⚕️',
  transport: '🚌',
  park: '🌳',
};

const MAX_CONTEXT_OBJECTS = 20; // лимит объектов в контексте ИИ (лимит токенов)
const REQUEST_TIMEOUT_MS = 60000; // клиентский таймаут запроса — 60 с

const state = {
  objects: window.OBJECTS || [],
  markers: {},        // id -> L.Marker
  layers: {},         // type -> L.LayerGroup (для фильтров)
  selected: null,     // выбранный объект («якорь» для вопросов ИИ)
  radiusCircle: null, // круг радиусом 1 км вокруг выбранного объекта
  mode: null,         // 'yandexgpt' | 'demo' (из /api/config)
  model: null,
  mentionTimer: null,
};

/* ------------------------------- утилиты ------------------------------- */

const $ = (sel) => document.querySelector(sel);

function escapeHtml(s) {
  const div = document.createElement('div');
  div.textContent = s == null ? '' : String(s);
  return div.innerHTML;
}

/** Нормализация текста для сравнения (поиск упоминаний в ответе ИИ). */
function norm(s) {
  return (s || '').toLowerCase().replaceAll('ё', 'е');
}
function compact(s) {
  return norm(s).replace(/[\s«»"'(),.-]/g, '');
}

/** Расстояние между двумя точками (формула гаверсинуса), метры. */
function haversineMeters(a, b) {
  const R = 6371000;
  const rad = Math.PI / 180;
  const dLat = (b.lat - a.lat) * rad;
  const dLng = (b.lng - a.lng) * rad;
  const la1 = a.lat * rad;
  const la2 = b.lat * rad;
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(la1) * Math.cos(la2) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(h));
}

function fmtDist(m) {
  return m >= 1000 ? `${(m / 1000).toFixed(1).replace('.', ',')} км` : `${Math.round(m)} м`;
}

function setStatus(text) {
  $('#status-line').textContent = text;
}

function showAlert(msg) {
  const box = $('#alert');
  box.textContent = `⚠️ ${msg}`;
  box.classList.remove('hidden');
}
function hideAlert() {
  $('#alert').classList.add('hidden');
}

/* -------------------------------- карта -------------------------------- */

const map = L.map('map', { zoomControl: true });

L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
  maxZoom: 19,
  attribution: '© участники <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
}).addTo(map);

L.control.scale({ imperial: false, position: 'bottomleft' }).addTo(map);

function popupHtml(o) {
  return `
    <div class="popup">
      <span class="popup-type type-${o.type}">${TYPE_EMOJI[o.type]} ${TYPE_LABELS[o.type]}</span>
      <div class="popup-name">${escapeHtml(o.name)}</div>
      <div class="popup-address">📍 ${escapeHtml(o.address)}</div>
      <div class="popup-desc">${escapeHtml(o.description || '')}</div>
      <div class="popup-coords">${o.lat.toFixed(5)}, ${o.lng.toFixed(5)}</div>
      <div class="popup-hint">✅ Объект выбран. Задайте вопрос в панели «ИИ-ассистент» слева.</div>
    </div>`;
}

function initMarkers() {
  Object.keys(TYPE_LABELS).forEach((t) => {
    state.layers[t] = L.layerGroup().addTo(map);
  });

  state.objects.forEach((o) => {
    const marker = L.marker([o.lat, o.lng], {
      title: o.name,
      icon: L.divIcon({
        className: 'marker-anchor',
        html: `<div class="pin pin-${o.type}">${TYPE_EMOJI[o.type]}</div>`,
        iconSize: [36, 36],
        iconAnchor: [18, 18],
        popupAnchor: [0, -18],
      }),
    });
    marker.bindPopup(popupHtml(o), { maxWidth: 300 });
    marker.on('click', () => selectObject(o.id));
    state.layers[o.type].addLayer(marker);
    state.markers[o.id] = marker;
  });

  // масштабируем карту так, чтобы были видны все объекты
  map.fitBounds(L.latLngBounds(state.objects.map((o) => [o.lat, o.lng])).pad(0.2));
}

/* --------------------- фильтры объектов по типам ----------------------- */

function initFilters() {
  const box = $('#filters');
  Object.keys(TYPE_LABELS).forEach((t) => {
    const count = state.objects.filter((o) => o.type === t).length;
    const row = document.createElement('label');
    row.className = 'filter-row';
    row.innerHTML = `
      <input type="checkbox" checked data-type="${t}">
      <span class="dot dot-${t}"></span>
      <span>${TYPE_EMOJI[t]} ${TYPE_LABELS[t]}</span>
      <span class="count">${count}</span>`;
    row.querySelector('input').addEventListener('change', (e) => {
      if (e.target.checked) map.addLayer(state.layers[t]);
      else map.removeLayer(state.layers[t]);
    });
    box.appendChild(row);
  });
}

/* ------------------ выбор объекта («якоря» для вопросов) ---------------- */

function selectObject(id) {
  if (state.selected && state.selected.id === id) return;
  clearSelection(true);

  const o = state.objects.find((x) => x.id === id);
  if (!o) return;
  state.selected = o;

  const el = state.markers[o.id] && state.markers[o.id].getElement();
  if (el) el.classList.add('selected');

  // визуальный ориентир: круг 1 км вокруг выбранного объекта
  state.radiusCircle = L.circle([o.lat, o.lng], {
    radius: 1000,
    color: '#2563eb',
    weight: 1.5,
    dashArray: '6 6',
    fillOpacity: 0.06,
  }).addTo(map);

  renderSelectedCard();
}

function clearSelection(silent) {
  if (state.selected && state.markers[state.selected.id]) {
    const el = state.markers[state.selected.id].getElement();
    if (el) el.classList.remove('selected');
  }
  if (state.radiusCircle) {
    map.removeLayer(state.radiusCircle);
    state.radiusCircle = null;
  }
  state.selected = null;
  if (!silent) renderSelectedCard();
}

function renderSelectedCard() {
  const box = $('#selected-card');
  if (!state.selected) {
    box.innerHTML = `
      <div class="selected-placeholder">
        Кликните объект на карте — он станет «якорем» для вопросов ИИ
        (например: «что находится рядом с этой школой?»).
        Вокруг выбранного объекта показывается круг радиусом 1 км.
      </div>`;
    return;
  }
  const o = state.selected;
  box.innerHTML = `
    <div class="selected-card">
      <span class="popup-type type-${o.type}">${TYPE_EMOJI[o.type]} ${TYPE_LABELS[o.type]}</span>
      <div class="sel-name">${escapeHtml(o.name)}</div>
      <div class="sel-row">📍 ${escapeHtml(o.address)}</div>
      <div class="sel-row">Координаты: ${o.lat.toFixed(5)}, ${o.lng.toFixed(5)}</div>
      <div class="sel-note">Для вопросов учитывается радиус 1 км (показан на карте).</div>
      <button id="btn-deselect" class="btn-ghost" type="button">✕ Снять выбор</button>
    </div>`;
  $('#btn-deselect').addEventListener('click', () => clearSelection());
}

/* =========================================================================
 * Формирование контекста для ИИ (ключевой фрагмент — см. отчёт).
 *
 * Логика:
 *  1) якорь = выбранный объект (если выбран) или центр видимой области карты;
 *  2) если объект не выбран — берём объекты в видимой области карты;
 *  3) сортируем по расстоянию от якоря (гаверсинус) и берём не более
 *     MAX_CONTEXT_OBJECTS ближайших — защита от превышения лимита токенов;
 *  4) сериализуем только значимые поля: id, name, type, address,
 *     lat, lng + вычисленное dist_m (расстояние от якоря в метрах).
 * ========================================================================= */

function buildContext() {
  const anchor = state.selected;
  const center = anchor ? L.latLng(anchor.lat, anchor.lng) : map.getCenter();

  let candidates = state.objects;
  if (!anchor) {
    const bounds = map.getBounds().pad(0.2);
    const visible = state.objects.filter((o) => bounds.contains([o.lat, o.lng]));
    if (visible.length >= 3) candidates = visible; // иначе берём все объекты
  }

  const objects = candidates
    .map((o) => ({ o, d: haversineMeters(center, L.latLng(o.lat, o.lng)) }))
    .sort((a, b) => a.d - b.d)
    .slice(0, MAX_CONTEXT_OBJECTS)
    .map(({ o, d }) => ({
      id: o.id,
      name: o.name,
      type: o.type,
      address: o.address,
      lat: o.lat,
      lng: o.lng,
      dist_m: Math.round(d),
    }));

  return {
    anchor: anchor
      ? {
          id: anchor.id,
          name: anchor.name,
          type: anchor.type,
          address: anchor.address,
          lat: anchor.lat,
          lng: anchor.lng,
        }
      : null,
    objects,
  };
}

/* ------------------------------- чат с ИИ ------------------------------- */

function appendChat(role, text, meta) {
  const chat = $('#chat');
  const empty = chat.querySelector('.chat-empty');
  if (empty) empty.remove();

  const item = document.createElement('div');
  item.className = 'chat-item';
  const metaHtml = meta ? `<div class="meta">${escapeHtml(meta)}</div>` : '';
  item.innerHTML = `<div class="bubble ${role}">${escapeHtml(text)}${metaHtml}</div>`;
  chat.appendChild(item);
  chat.scrollTop = chat.scrollHeight;
}

async function onAsk(e) {
  e.preventDefault();

  const input = $('#question-input');
  const btn = $('#ask-btn');
  const question = input.value.trim();

  // 1) валидация на клиенте: пустой вопрос
  if (!question) {
    showAlert('Введите вопрос — поле не заполнено.');
    input.focus();
    return;
  }
  hideAlert();
  clearMentions();

  // 2) формируем контекст и отправляем на прокси
  const ctx = buildContext();
  appendChat('user', question);

  input.value = '';
  input.disabled = true;
  btn.disabled = true;
  setStatus('ИИ анализирует данные карты…');

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);

  try {
    const res = await fetch('/api/ask', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        question,
        context: ctx.objects,          // список объектов с координатами
        selectedObject: ctx.anchor,    // выбранный объект (если есть)
      }),
      signal: controller.signal,
    });

    const data = await res.json().catch(() => ({}));

    if (!res.ok) {
      // 3) ошибка от сервера/API — показываем понятное сообщение
      const msg = data.error || `Ошибка сервера (HTTP ${res.status}).`;
      showAlert(msg);
      appendChat('ai', `❌ ${msg}`);
      setStatus('Ошибка запроса — см. сообщение выше.');
    } else {
      const meta =
        data.mode === 'yandexgpt'
          ? `YandexGPT · ${data.model || state.model || ''}`
          : 'локальный анализ (демо-режим)';
      appendChat('ai', data.answer, meta);
      setStatus('Готово.');
      highlightMentioned(data.answer); // 10 (опция): подсветка упомянутых объектов
    }
  } catch (err) {
    // 4) сетевые ошибки и клиентский таймаут
    if (err.name === 'AbortError') {
      showAlert('Превышено время ожидания ответа (60 с). Проверьте сеть и повторите вопрос.');
      appendChat('ai', '❌ Превышено время ожидания ответа (таймаут 60 с).');
    } else {
      showAlert('Не удалось связаться с сервером. Убедитесь, что Flask запущен: python app.py');
      appendChat('ai', '❌ Сервер недоступен.');
    }
    setStatus('Ошибка сети.');
  } finally {
    clearTimeout(timer);
    input.disabled = false;
    btn.disabled = false;
    input.focus();
  }
}

/* ------------- подсветка объектов, упомянутых в ответе ИИ -------------- */

function highlightMentioned(answer) {
  clearMentions();
  const a = compact(answer);

  const mentioned = state.objects.filter((o) => {
    const variants = [compact(o.name)];
    const base = compact(o.name.split('(')[0]); // «Парк культуры и отдыха (ЦПКиО)» → «Парк культуры и отдыха»
    if (base.length > 4) variants.push(base);
    return variants.some((v) => v.length > 4 && a.includes(v));
  });
  if (!mentioned.length) return;

  const box = $('#mentioned');
  box.classList.remove('hidden');
  box.innerHTML = '<span class="mentioned-label">Упомянуты на карте:</span>';

  mentioned.forEach((o) => {
    const el = state.markers[o.id] && state.markers[o.id].getElement();
    if (el) el.classList.add('mentioned');

    const chip = document.createElement('button');
    chip.type = 'button';
    chip.className = 'chip';
    chip.textContent = `${TYPE_EMOJI[o.type]} ${o.name}`;
    chip.addEventListener('click', () => {
      map.flyTo([o.lat, o.lng], 17, { duration: 0.8 });
      state.markers[o.id].openPopup();
      selectObject(o.id);
    });
    box.appendChild(chip);
  });

  state.mentionTimer = setTimeout(clearMentions, 20000);
}

function clearMentions() {
  if (state.mentionTimer) {
    clearTimeout(state.mentionTimer);
    state.mentionTimer = null;
  }
  Object.values(state.markers).forEach((m) => {
    const el = m.getElement();
    if (el) el.classList.remove('mentioned');
  });
  const box = $('#mentioned');
  box.classList.add('hidden');
  box.innerHTML = '';
}

/* --------------------- статус подключения к ИИ-сервису ------------------ */

async function loadConfig() {
  const badge = $('#mode-badge');
  try {
    const res = await fetch('/api/config');
    const cfg = await res.json();
    state.mode = cfg.mode;
    state.model = cfg.model;

    if (cfg.mode === 'yandexgpt') {
      badge.textContent = `YandexGPT: ${cfg.model}`;
      badge.classList.add('api');
      setStatus(`Готов. Вопросы обрабатывает YandexGPT (${cfg.model}).`);
    } else {
      badge.textContent = 'Демо-режим (ключи не настроены)';
      badge.classList.add('demo');
      setStatus('Демо-режим: ответы строит локальный анализатор координат. Добавьте ключи в .env для YandexGPT.');
    }
  } catch {
    badge.textContent = 'Сервер недоступен';
    badge.classList.add('error');
    setStatus('Не удалось получить конфигурацию сервера. Запустите: python app.py');
  }
}

/* -------------------------- примеры вопросов ---------------------------- */

const EXAMPLES = [
  'Сколько школ находится в радиусе 1 км от выбранной остановки?',
  'Какие парки есть рядом с этой поликлиникой?',
  'Какой объект инфраструктуры ближе всего к ботаническому саду?',
];

function initExamples() {
  const box = $('#examples');
  EXAMPLES.forEach((q) => {
    const chip = document.createElement('button');
    chip.type = 'button';
    chip.className = 'example-chip';
    chip.textContent = q.length > 44 ? `${q.slice(0, 44)}…` : q;
    chip.title = q;
    chip.addEventListener('click', () => {
      $('#question-input').value = q;
      $('#question-input').focus();
    });
    box.appendChild(chip);
  });
}

/* --------------------------------- старт -------------------------------- */

document.addEventListener('DOMContentLoaded', () => {
  initMarkers();
  initFilters();
  renderSelectedCard();
  initExamples();
  loadConfig();
  $('#ask-form').addEventListener('submit', onAsk);
  map.on('click', () => clearSelection()); // клик по пустой карте — снять выбор
});
