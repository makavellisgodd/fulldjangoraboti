# -*- coding: utf-8 -*-
"""
Умная карта района Хамовники — ГИС + ИИ (серверная часть).

Flask-приложение:
  1) отдаёт фронтенд (карта на Leaflet.js + OpenStreetMap, static/);
  2) проксирует запросы к YandexGPT
     (https://llm.api.cloud.yandex.net/foundationModels/v1/completion),
     скрывая IAM/OAuth-токен на сервере — прямо из браузера токен
     передавать небезопасно;
  3) если OAuth-токен задан, сам обменивает его на короткоживущий
     IAM-токен (12 ч) и автообновляет его (см. get_iam_token);
  4) если ключи не настроены — работает в демо-режиме: ответ строится
     локальным анализом координат, чтобы приложение можно было
     протестировать до настройки Yandex Cloud.

Запуск:  python app.py  →  http://127.0.0.1:5000
Настройка ключей — в файле .env (шаблон: .env.example).
"""

import json
import math
import os
import re
import threading
import time
from datetime import datetime

import requests
from dotenv import load_dotenv
from flask import Flask, jsonify, request, send_from_directory
from werkzeug.exceptions import HTTPException

load_dotenv()

# ---------------------------------------------------------------------------
# Конфигурация (значения из .env, см. .env.example)
# ---------------------------------------------------------------------------
FOLDER_ID = os.getenv("YANDEX_FOLDER_ID", "").strip()
OAUTH_TOKEN = os.getenv("YANDEX_OAUTH_TOKEN", "").strip()
IAM_TOKEN = os.getenv("YANDEX_IAM_TOKEN", "").strip()
MODEL_NAME = os.getenv("YANDEXGPT_MODEL", "yandexgpt-lite").strip() or "yandexgpt-lite"
PORT = int(os.getenv("PORT", "5000"))
DEBUG = os.getenv("FLASK_DEBUG", "1") == "1"

MAX_CONTEXT_OBJECTS = 20  # лимит объектов в контексте (защита от лимита токенов)
HARD_CONTEXT_LIMIT = 60   # больше — отказ (HTTP 400)

IAM_URL = "https://iam.api.cloud.yandex.net/iam/v1/tokens"
LLM_URL = "https://llm.api.cloud.yandex.net/foundationModels/v1/completion"
LLM_TIMEOUT = (10, 60)  # (таймаут соединения, таймаут чтения), сек

SYSTEM_PROMPT = (
    "Ты — ГИС-ассистент интерактивной карты города Якутска (Республика Саха, "
    "широта ~62°, поэтому 1° долготы ≈ 522 м). "
    "Тебе передают список объектов инфраструктуры в формате JSON: у каждого объекта "
    "поля id, name, type (school | clinic | transport | park), address, lat, lng и "
    "dist_m — расстояние в метрах от точки отсчёта (выбранный пользователем объект "
    "или центр видимой области карты). Отвечай кратко и по существу, на русском языке, "
    "используя ТОЛЬКО предоставленные данные. Если данных для ответа недостаточно — "
    "честно скажи об этом. Вопросы про «рядом» и радиус решай по полю dist_m. "
    "Перечисляя объекты, называй их точные названия и расстояния."
)

# Подсказки для типовых ошибок YandexGPT API (для понятных сообщений пользователю)
ERROR_HINTS = {
    400: "Ошибка валидации запроса. Частая причина — превышен лимит токенов: "
         "контекст уже ограничен 20 ближайшими объектами, попробуйте упростить вопрос.",
    401: "Неверный или просроченный токен. IAM-токен живёт 12 часов — обновите его "
         "(YANDEX_IAM_TOKEN) либо используйте OAuth-токен (обменивается автоматически).",
    403: "Нет доступа к модели. Проверьте Folder ID и роль сервисного аккаунта "
         "ai.languageModels.user.",
    429: "Превышен лимит запросов/квоты YandexGPT. Подождите немного и повторите вопрос.",
    503: "Сервис YandexGPT временно перегружен, попробуйте позже.",
}

app = Flask(__name__, static_folder="static", static_url_path="")


def credentials_configured() -> bool:
    """Проверка: настроены ли ключи Yandex Cloud."""
    return bool(FOLDER_ID and (IAM_TOKEN or OAUTH_TOKEN))


# ---------------------------------------------------------------------------
# IAM-токен: обмен OAuth → IAM с кэшированием и автообновлением
# ---------------------------------------------------------------------------
_iam_lock = threading.Lock()
_iam_cache = {"token": None, "expires_at": 0.0}


def _parse_expires_at(value: str) -> float:
    """expiresAt вида '2026-11-24T12:34:56.789+00:00' → unix-время."""
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00")).timestamp()
    except (TypeError, ValueError):
        return time.time() + 11 * 3600  # консервативная оценка: 11 часов


def get_iam_token():
    """Возвращает (iam_token, error). Обновляет токен автоматически."""
    if IAM_TOKEN:  # токен задан вручную — используем как есть
        return IAM_TOKEN, None
    if not OAUTH_TOKEN:
        return None, "не настроены ключи (YANDEX_FOLDER_ID и токен в .env)"

    with _iam_lock:
        if _iam_cache["token"] and time.time() < _iam_cache["expires_at"] - 300:
            return _iam_cache["token"], None

        try:
            resp = requests.post(
                IAM_URL,
                json={"yandexPassportOauthToken": OAUTH_TOKEN},
                timeout=10,
            )
        except requests.RequestException as exc:
            return None, f"сеть недоступна при обмене OAuth→IAM ({exc.__class__.__name__})"

        if resp.status_code != 200:
            return None, (
                f"OAuth-токен отклонён (HTTP {resp.status_code}). "
                "Получите свежий OAuth-токен и обновите YANDEX_OAUTH_TOKEN в .env"
            )

        data = resp.json()
        token = data.get("iamToken")
        if not token:
            return None, "в ответе IAM-сервиса нет поля iamToken"
        _iam_cache["token"] = token
        _iam_cache["expires_at"] = _parse_expires_at(data.get("expiresAt", ""))
        return token, None


# ---------------------------------------------------------------------------
# Гео-утилиты (для пересчёта расстояний на сервере и демо-режима)
# ---------------------------------------------------------------------------
def haversine(lat1, lon1, lat2, lon2) -> float:
    """Расстояние между точками в метрах (формула гаверсинуса)."""
    r = 6371000.0
    p = math.pi / 180.0
    d_lat = (lat2 - lat1) * p
    d_lon = (lon2 - lon1) * p
    a = (math.sin(d_lat / 2) ** 2
         + math.cos(lat1 * p) * math.cos(lat2 * p) * math.sin(d_lon / 2) ** 2)
    return 2 * r * math.asin(math.sqrt(a))


def fmt_dist(m) -> str:
    m = int(round(m))
    return f"{m / 1000:.1f}".replace(".", ",") + " км" if m >= 1000 else f"{m} м"


# ---------------------------------------------------------------------------
# Демо-режим: локальный анализ координат вместо YandexGPT
# ---------------------------------------------------------------------------
TYPE_KEYWORDS = {
    "school": ("школа", ["школ", "гимназ", "лице", "учеб", "образов", "ученик"]),
    "clinic": ("поликлиника",
               ["поликлин", "клиник", "больниц", "медиц", "врач", "аптек",
                "стоматолог", "диагност", "кдц", "лекар", "здоров"]),
    "transport": ("остановка транспорта",
                  ["останов", "метро", "мцк", "транспорт", "автобус", "трамва",
                   "троллейб", "станци", "электричк", "вокзал"]),
    "park": ("парк", ["парк", "сквер", "зелен", "зелён", "прогул", "отдых", "дерев"]),
}
TYPE_PLURAL = {"school": "школ", "clinic": "поликлиник",
               "transport": "остановок транспорта", "park": "парков"}


def parse_radius_m(question: str) -> int:
    """Радиус из вопроса («в радиусе 1 км», «500 м»). По умолчанию 1000 м."""
    q = question.lower()
    m = re.search(r"(\d+(?:[.,]\d+)?)\s*(км|километр)", q)
    if m:
        return int(float(m.group(1).replace(",", ".")) * 1000)
    m = re.search(r"(\d{3,6})\s*(м\b|метр)", q)
    if m:
        v = int(m.group(1))
        if 50 <= v <= 100_000:
            return v
    return 1000


def demo_answer(question, context, selected):
    """Ответ локального анализатора, если ключи YandexGPT не настроены."""
    q = question.lower()
    radius = parse_radius_m(q)
    detected = [t for t, (_, kws) in TYPE_KEYWORDS.items() if any(k in q for k in kws)]

    # расстояния считаем на сервере — клиентским данным не доверяем
    for o in context:
        if selected and isinstance(o.get("lat"), (int, float)):
            o["dist_m"] = round(haversine(selected["lat"], selected["lng"], o["lat"], o["lng"]))

    header = ("⚠️ ДЕМО-РЕЖИМ: ключи YandexGPT не настроены (.env). Ответ построен "
              "локальным анализом координат. Заполните YANDEX_FOLDER_ID и токен, "
              "чтобы получать ответы ИИ.")

    lines = []
    if selected and detected:
        for t in detected:
            same_type = [o for o in context
                         if o.get("type") == t and o.get("id") != selected.get("id")]
            within = sorted((o for o in same_type if o.get("dist_m", 10**9) <= radius),
                            key=lambda o: o["dist_m"])
            if within:
                lines.append(f"В радиусе {fmt_dist(radius)} от «{selected['name']}» "
                             f"находится {len(within)} {TYPE_PLURAL[t]}:")
                lines.extend(f"  • {o['name']} ({o.get('address', '')}) — {fmt_dist(o['dist_m'])}"
                             for o in within)
            elif same_type:
                nearest = min(same_type, key=lambda o: o["dist_m"])
                lines.append(f"В радиусе {fmt_dist(radius)} от «{selected['name']}» "
                             f"{TYPE_PLURAL[t]} нет. Ближайшая "
                             f"{TYPE_KEYWORDS[t][0]}: «{nearest['name']}» — "
                             f"{fmt_dist(nearest['dist_m'])}.")
            else:
                lines.append(f"В переданном контексте нет {TYPE_PLURAL[t]}.")
    elif selected:
        nearest = sorted(context, key=lambda o: o.get("dist_m", 10**9))[:5]
        lines.append(f"Ближайшие объекты к «{selected['name']}» "
                     f"(в скобках — расстояние):")
        lines.extend(f"  • {o['name']} — {fmt_dist(o.get('dist_m', 0))}" for o in nearest)
    elif detected:
        for t in detected:
            items = [o for o in context if o.get("type") == t]
            if items:
                names = ", ".join(f"«{o['name']}»" for o in items)
                lines.append(f"В переданных данных {TYPE_PLURAL[t]}: {len(items)} — {names}.")
            else:
                lines.append(f"В переданных данных нет {TYPE_PLURAL[t]}.")
    else:
        stats = {t: sum(1 for o in context if o.get("type") == t) for t in TYPE_KEYWORDS}
        parts = ", ".join(f"{TYPE_PLURAL[t]} — {n}" for t, n in stats.items())
        lines.append(f"В переданном контексте {len(context)} объектов: {parts}.")
        lines.append("Уточните вопрос (например, «сколько школ в радиусе 500 м от "
                     "выбранной остановки?») и выберите объект на карте.")

    return header + "\n\n" + "\n".join(lines)


# ---------------------------------------------------------------------------
# Промпт для YandexGPT
# ---------------------------------------------------------------------------
def build_user_prompt(question, context, selected, truncated) -> str:
    lines = [
        "Ниже — список объектов инфраструктуры города Якутска в формате JSON.",
        "У каждого объекта: id, name (название), type (school|clinic|transport|park),",
        "address (адрес), lat/lng (координаты) и dist_m — расстояние в метрах от точки",
        "отсчёта: от выбранного пользователем объекта, если он задан, иначе от центра",
        "видимой области карты.",
        "Ответь на вопрос пользователя, используя ТОЛЬКО эти данные. Если ответа в данных",
        "нет — прямо скажи об этом. Вопросы про «рядом»/«в радиусе» решай по полю dist_m.",
    ]
    if truncated:
        lines.append("(Внимание: в контекст включены только 20 ближайших объектов.)")
    if selected:
        lines.append(f"Выбранный пользователем объект (якорь): "
                     f"{json.dumps(selected, ensure_ascii=False)}")
    else:
        lines.append("Объект пользователем НЕ выбран: если вопрос про «выбранный объект», "
                     "попроси сначала кликнуть объект на карте; на общие вопросы по списку "
                     "ответь сразу.")
    lines.append(f"Вопрос пользователя: {question}")
    lines.append("Данные (JSON):")
    lines.append(json.dumps(context, ensure_ascii=False))
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Маршруты
# ---------------------------------------------------------------------------
@app.route("/")
def index():
    return send_from_directory("static", "index.html")


@app.get("/api/config")
def api_config():
    """Статус подключения к ИИ-сервису (для бейджа в интерфейсе)."""
    if credentials_configured():
        return jsonify({"mode": "yandexgpt", "model": MODEL_NAME})
    return jsonify({"mode": "demo", "model": "локальный анализ (демо)"})


@app.post("/api/ask")
def api_ask():
    """Прокси-запрос к YandexGPT: {question, context, selectedObject} → {answer}."""
    payload = request.get_json(silent=True) or {}
    question = str(payload.get("question") or "").strip()
    context = payload.get("context") or []
    selected = payload.get("selectedObject") or None

    # --- валидация входных данных ---
    if not question:
        return jsonify({"error": "Пустой вопрос — введите текст вопроса."}), 400
    if not isinstance(context, list) or not context:
        return jsonify({"error": "Контекст пуст — на карте нет объектов для анализа."}), 400

    # чистим и валидируем элементы контекста
    context = [
        o for o in context
        if isinstance(o, dict) and "name" in o and "lat" in o and "lng" in o
    ]
    if not context:
        return jsonify({"error": "Некорректный контекст: нет объектов с координатами."}), 400
    if len(context) > HARD_CONTEXT_LIMIT:
        return jsonify({"error": f"Слишком большой контекст ({len(context)} объектов > "
                                 f"{HARD_CONTEXT_LIMIT}). Ограничьте выборку на клиенте."}), 400

    truncated = len(context) > MAX_CONTEXT_OBJECTS
    context = context[:MAX_CONTEXT_OBJECTS]

    # пересчитываем расстояния на сервере (клиентским dist_m не доверяем)
    if selected and "lat" in selected and "lng" in selected:
        for o in context:
            if isinstance(o.get("lat"), (int, float)) and isinstance(o.get("lng"), (int, float)):
                o["dist_m"] = round(haversine(selected["lat"], selected["lng"],
                                              o["lat"], o["lng"]))

    # --- демо-режим, если ключи не настроены ---
    if not credentials_configured():
        return jsonify({"answer": demo_answer(question, context, selected), "mode": "demo"})

    # --- получаем IAM-токен ---
    iam, err = get_iam_token()
    if err:
        return jsonify({"error": f"Ошибка авторизации Yandex Cloud: {err}"}), 401

    # --- запрос к YandexGPT ---
    body = {
        "modelUri": f"gpt://{FOLDER_ID}/{MODEL_NAME}",
        "completionOptions": {"temperature": 0.3, "maxTokens": 500},
        "messages": [
            {"role": "system", "text": SYSTEM_PROMPT},
            {"role": "user", "text": build_user_prompt(question, context, selected, truncated)},
        ],
    }
    headers = {
        "Authorization": f"Bearer {iam}",
        "x-data-logging-enabled": "false",  # не отправлять данные на дообучение
    }

    try:
        resp = requests.post(LLM_URL, json=body, headers=headers, timeout=LLM_TIMEOUT)
    except requests.Timeout:
        return jsonify({"error": "Превышено время ожидания YandexGPT (таймаут 60 с). "
                                 "Попробуйте повторить вопрос."}), 504
    except requests.RequestException as exc:
        return jsonify({"error": f"Сетевая ошибка при обращении к YandexGPT: "
                                 f"{exc.__class__.__name__}"}), 502

    if resp.status_code != 200:
        hint = ERROR_HINTS.get(resp.status_code, "Неизвестная ошибка YandexGPT API.")
        detail = ""
        try:
            detail = (resp.json().get("error", {}) or {}).get("message", "") or resp.text[:200]
        except ValueError:
            detail = resp.text[:200]
        code = resp.status_code if resp.status_code in (400, 401, 403, 408, 429) else 502
        return jsonify({"error": f"YandexGPT API (HTTP {resp.status_code}): {hint} {detail}"}), code

    # --- разбор ответа модели ---
    try:
        data = resp.json()
        answer = data["result"]["alternatives"][0]["message"]["text"].strip()
    except (KeyError, IndexError, ValueError, AttributeError):
        return jsonify({"error": "Не удалось разобрать ответ YandexGPT "
                                 "(пустой или неожиданный формат ответа)."}), 502

    return jsonify({"answer": answer, "mode": "yandexgpt", "model": MODEL_NAME})


# ---------------------------------------------------------------------------
# CORS-заголовки и обработка ошибок
# ---------------------------------------------------------------------------
@app.after_request
def add_cors_headers(response):
    """Прокси добавляет CORS-заголовки к API-ответам (можно звать и с другого origin)."""
    if request.path.startswith("/api/"):
        response.headers["Access-Control-Allow-Origin"] = "*"
        response.headers["Access-Control-Allow-Headers"] = "Content-Type"
        response.headers["Access-Control-Allow-Methods"] = "GET, POST, OPTIONS"
    return response


@app.errorhandler(404)
def not_found(_exc):
    if request.path.startswith("/api/"):
        return jsonify({"error": "Маршрут не найден."}), 404
    return jsonify({"error": "Страница не найдена."}), 404


@app.errorhandler(Exception)
def on_unexpected(exc):
    """Любые необработанные ошибки возвращаем в JSON, а не HTML-страницей."""
    if isinstance(exc, HTTPException):
        return jsonify({"error": exc.description}), exc.code
    app.logger.exception("Необработанная ошибка")
    return jsonify({"error": f"Внутренняя ошибка сервера: {exc}"}), 500


if __name__ == "__main__":
    # Для лабораторной работы достаточно dev-сервера Flask.
    # В production: waitress/gunicorn + автоматически обновляемый IAM-токен
    # (уже реализовано через OAuth-обмен в get_iam_token).
    print(f" * Режим ИИ: {'YandexGPT (' + MODEL_NAME + ')' if credentials_configured() else 'ДЕМО (ключи не настроены)'}")
    print(f" * Откройте в браузере: http://127.0.0.1:{PORT}")
    app.run(host="127.0.0.1", port=PORT, debug=DEBUG)
