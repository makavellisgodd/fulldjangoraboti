# -*- coding: utf-8 -*-
"""
Тестирование API умной карты (без запуска сервера — через Flask test-client).

Сценарии (см. этап 5 задания):
  1. Демо-режим (ключи не настроены):
     - пустой вопрос → 400 + сообщение;
     - обычный вопрос с выбранным объектом → локальный ответ;
     - вопрос с контекстом из 40 объектов → усечение до 20;
     - контекст из 100 объектов → 400 (слишком большой контекст);
     - пустой контекст → 400.
  2. Неверный IAM-токен → понятная ошибка авторизации (401/403/502/504).

Запуск:  python test_api.py
"""

import importlib
import os
import sys

sys.stdout.reconfigure(encoding="utf-8")

# убираем возможные реальные ключи, чтобы гарантировать демо-режим
for key in ("YANDEX_FOLDER_ID", "YANDEX_OAUTH_TOKEN", "YANDEX_IAM_TOKEN"):
    os.environ.pop(key, None)

import app as app_module  # noqa: E402


def client():
    return app_module.app.test_client()


def check(name, ok, detail=""):
    print(f"{'PASS' if ok else 'FAIL'}  {name}" + (f"  → {detail}" if detail else ""))
    return ok


def make_objects(n):
    return [
        {
            "id": i,
            "name": f"Объект № {i}",
            "type": ["school", "clinic", "transport", "park"][i % 4],
            "address": f"ул. Тестовая, {i}",
            "lat": 55.72 + i * 0.001,
            "lng": 37.56 + i * 0.001,
            "dist_m": 100 * i,
        }
        for i in range(1, n + 1)
    ]


SELECTED = {
    "id": 20,
    "name": "Остановка «Кинотеатр Центральный»",
    "type": "transport",
    "address": "пр. Ленина",
    "lat": 62.0308,
    "lng": 129.7387,
}

REAL_CONTEXT = [
    {"id": 6, "name": "Якутская городская национальная гимназия", "type": "school",
     "address": "ул. Пояркова, 16", "lat": 62.0364, "lng": 129.7320, "dist_m": 0},
    {"id": 7, "name": "Школа № 33 им. Л.А. Колосовой", "type": "school",
     "address": "202-й микрорайон, 21", "lat": 62.0347, "lng": 129.7564, "dist_m": 0},
    {"id": 8, "name": "Школа № 26", "type": "school",
     "address": "ул. Ярославского", "lat": 62.0279, "lng": 129.7407, "dist_m": 0},
    {"id": 10, "name": "Школа № 7", "type": "school",
     "address": "ул. Шавкунова, 63", "lat": 62.0362, "lng": 129.7267, "dist_m": 0},
    {"id": 1, "name": "Парк культуры и отдыха (ЦПКиО)", "type": "park",
     "address": "ул. Петра Алексеева", "lat": 62.0422, "lng": 129.6987, "dist_m": 0},
    {"id": 11, "name": "Поликлиника № 1", "type": "clinic",
     "address": "ул. Кирова", "lat": 62.0296, "lng": 129.7255, "dist_m": 0},
]


def ask(question, context, selected=None):
    return client().post(
        "/api/ask",
        json={"question": question, "context": context, "selectedObject": selected},
    )


def main():
    results = []

    # ------------------- демо-режим: базовые сценарии -------------------
    r = client().get("/api/config")
    results.append(check(
        "GET /api/config → демо-режим, HTTP 200",
        r.status_code == 200 and r.get_json()["mode"] == "demo",
        str(r.get_json()),
    ))

    r = ask("", REAL_CONTEXT)
    results.append(check(
        "пустой вопрос → HTTP 400, понятное сообщение",
        r.status_code == 400 and "Пустой вопрос" in r.get_json()["error"],
        f"HTTP {r.status_code}: {r.get_json()['error']}",
    ))

    r = ask("Сколько школ в радиусе 1 км?", [], None)
    results.append(check(
        "пустой контекст → HTTP 400",
        r.status_code == 400,
        f"HTTP {r.status_code}: {r.get_json()['error']}",
    ))

    r = ask("Сколько школ в радиусе 1 км от этой остановки?",
            REAL_CONTEXT, SELECTED)
    body = r.get_json()
    results.append(check(
        "демо-вопрос с выбранным объектом → HTTP 200, ответ с подсчётом",
        r.status_code == 200 and "ДЕМО-РЕЖИМ" in body["answer"] and "школ" in body["answer"].lower(),
        f"HTTP {r.status_code}",
    ))
    print("      Ответ демо-анализатора:")
    for line in body["answer"].splitlines():
        print(f"        {line}")

    r = ask("Сколько школ рядом?", make_objects(40), None)
    results.append(check(
        "контекст из 40 объектов → усечение до 20 (защита лимита токенов)",
        r.status_code == 200 and "20" in r.get_json()["answer"],
        f"HTTP {r.status_code}",
    ))

    r = ask("Сколько школ рядом?", make_objects(100), None)
    results.append(check(
        "контекст из 100 объектов → HTTP 400 (превышение лимита)",
        r.status_code == 400,
        f"HTTP {r.status_code}: {r.get_json()['error']}",
    ))

    # ------------- неверный токен → понятная ошибка API -------------
    os.environ["YANDEX_IAM_TOKEN"] = "fake-iam-token-for-error-testing"
    os.environ["YANDEX_FOLDER_ID"] = "b1gfakefolder"
    importlib.reload(app_module)  # перечитываем конфигурацию

    r = ask("Сколько школ рядом?", REAL_CONTEXT, None)
    body = r.get_json()
    ok = r.status_code in (401, 403, 502, 504) and "error" in body
    results.append(check(
        "неверный IAM-токен → HTTP 401/403/502, понятное сообщение",
        ok,
        f"HTTP {r.status_code}: {body.get('error', '')[:120]}",
    ))

    # возвращаем демо-режим для последующих запусков
    for key in ("YANDEX_IAM_TOKEN", "YANDEX_FOLDER_ID"):
        os.environ.pop(key, None)
    importlib.reload(app_module)

    print()
    print(f"Итого: {sum(results)}/{len(results)} проверок пройдено")
    sys.exit(0 if all(results) else 1)


if __name__ == "__main__":
    main()
